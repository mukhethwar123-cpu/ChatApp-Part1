import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class MessageManagerTest {
    private MessageManager manager;
    private Message msg1, msg2, msg3, msg4, msg5;

    @BeforeEach
    public void setUp() {
        manager = new MessageManager(20);
        msg1 = new Message("MSG001", "+27834557896", "Developer 1", "Did you get the cake?", "Sent");
        msg2 = new Message("MSG002", "+27838884567", "Developer 2", "Where are you? You are late! I have asked you to be on time.", "Stored");
        msg3 = new Message("MSG003", "+27834484567", "Developer 3", "Yohoooo, I am at your gate.", "Disregard");
        msg4 = new Message("0838884567", "+27838884567", "0838884567", "It is dinner time!", "Sent");
        msg5 = new Message("MSG005", "+27838884567", "Developer 5", "Ok, I am leaving without you.", "Stored");

        manager.addMessage(msg1);
        manager.addMessage(msg2);
        manager.addMessage(msg3);
        manager.addMessage(msg4);
        manager.addMessage(msg5);
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        String[] expected = {"Did you get the cake?", "It is dinner time!"};
        assertArrayEquals(expected, manager.getPopulatedSentMessages());
    }

    @Test
    public void testDisplayLongestMessage() {
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, manager.getLongestMessage());
    }

    @Test
    public void testSearchForMessageID() {
        String actual = manager.getMessageTextByID("0838884567");
        assertEquals("It is dinner time!", actual);
    }

    @Test
    public void testSearchMessagesForRecipient() {
        List<String> expected = Arrays.asList(
            "Where are you? You are late! I have asked you to be on time.",
            "It is dinner time!",
            "Ok, I am leaving without you."
        );
        List<String> actual = manager.searchMessagesByRecipient("+27838884567");
        assertTrue(actual.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(actual.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        String hashToDelete = msg2.getMessageHash();
        String result = manager.deleteMessageByHash(hashToDelete);
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", result);
    }

    @Test
    public void testDisplayReport() {
        String report = manager.displayFullReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time!"));
        assertTrue(report.contains(msg1.getMessageHash()));
    }
}
