# PROG5121 POE - Part 3: Store Data and Display Task Report

## Project Structure
- `src/Message.java` — Model class representing a message and generating the Message Hash.
- `src/MessageManager.java` — Manages all arrays (`sentMessages`, `disregardedMessages`, `storedMessages`, `messageHashes`, `messageIDs`), JSON persistence, search, delete, and report generation.
- `src/Main.java` — Console application with the 4th Main Menu option ("Stored Messages") and sub-options `a` through `f`.
- `test/MessageManagerTest.java` — Automated JUnit 5 unit tests covering all Part 3 test cases.

## How to Run in VS Code
1. Open the `PROG5121_POE_Part3` folder in **Visual Studio Code**.
2. Ensure you have the **Extension Pack for Java** installed.
3. Run `src/Main.java` to test the interactive menu and JSON file creation (`stored_messages.json`).
4. Open `test/MessageManagerTest.java` and click **Run Test** above the class or individual `@Test` methods to execute all unit tests.
5. **Important:** Connect your Part 1 (Registration/Login) and Part 2 (Message validation/sending) classes into `Main.java` before submitting your final POE.
