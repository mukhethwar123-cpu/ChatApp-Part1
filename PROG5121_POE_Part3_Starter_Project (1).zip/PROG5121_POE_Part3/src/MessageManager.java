import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MessageManager {
    // Required arrays from Part 3 specification
    private String[] sentMessages;
    private String[] disregardedMessages;
    private String[] storedMessages;
    private String[] messageHashes;
    private String[] messageIDs;

    // Parallel arrays for full record lookup (recipients, developers, flags)
    private String[] recipients;
    private String[] developers;
    private String[] flags;
    private String[] allMessages;

    private int count;

    public MessageManager(int capacity) {
        sentMessages = new String[capacity];
        disregardedMessages = new String[capacity];
        storedMessages = new String[capacity];
        messageHashes = new String[capacity];
        messageIDs = new String[capacity];
        recipients = new String[capacity];
        developers = new String[capacity];
        flags = new String[capacity];
        allMessages = new String[capacity];
        count = 0;
    }

    private int sentCount = 0;
    private int disregardedCount = 0;
    private int storedCount = 0;

    // Populates arrays dynamically (no hard-coding inside logic)
    public void addMessage(Message msg) {
        if (count >= allMessages.length) {
            return;
        }
        allMessages[count] = msg.getMessageText();
        messageIDs[count] = msg.getMessageID();
        messageHashes[count] = msg.getMessageHash();
        recipients[count] = msg.getRecipient();
        developers[count] = msg.getDeveloper();
        flags[count] = msg.getFlag();
        count++;

        if ("Sent".equalsIgnoreCase(msg.getFlag())) {
            sentMessages[sentCount++] = msg.getMessageText();
        } else if ("Disregard".equalsIgnoreCase(msg.getFlag()) || "Disregarded".equalsIgnoreCase(msg.getFlag())) {
            disregardedMessages[disregardedCount++] = msg.getMessageText();
        } else if ("Stored".equalsIgnoreCase(msg.getFlag())) {
            storedMessages[storedCount++] = msg.getMessageText();
        }
    }

    // Save stored messages to JSON file
    public void saveStoredMessagesToJson(String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write("[\n");
            boolean first = true;
            for (int i = 0; i < count; i++) {
                if ("Stored".equalsIgnoreCase(flags[i])) {
                    if (!first) {
                        writer.write(",\n");
                    }
                    writer.write("  {\n");
                    writer.write("    \"messageID\": \"" + escapeJson(messageIDs[i]) + "\",\n");
                    writer.write("    \"recipient\": \"" + escapeJson(recipients[i]) + "\",\n");
                    writer.write("    \"developer\": \"" + escapeJson(developers[i]) + "\",\n");
                    writer.write("    \"message\": \"" + escapeJson(allMessages[i]) + "\",\n");
                    writer.write("    \"flag\": \"" + escapeJson(flags[i]) + "\",\n");
                    writer.write("    \"messageHash\": \"" + escapeJson(messageHashes[i]) + "\"\n");
                    writer.write("  }");
                    first = false;
                }
            }
            writer.write("\n]\n");
        } catch (IOException e) {
            System.out.println("Error saving JSON file: " + e.getMessage());
        }
    }

    // Read stored messages from JSON file into storedMessages array
    public String[] loadStoredMessagesFromJson(String filePath) {
        List<String> loaded = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("\"message\":")) {
                    String value = line.substring("\"message\":".length()).trim();
                    if (value.endsWith(",")) {
                        value = value.substring(0, value.length() - 1);
                    }
                    if (value.startsWith("\"") && value.endsWith("\"")) {
                        value = value.substring(1, value.length() - 1);
                    }
                    loaded.add(value);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
        }
        storedMessages = loaded.toArray(new String[0]);
        storedCount = storedMessages.length;
        return storedMessages;
    }

    private String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // Option 2a: Display sender and recipient of all stored messages
    public String displaySenderAndRecipientOfStored() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if ("Stored".equalsIgnoreCase(flags[i])) {
                sb.append("Sender/Developer: ").append(developers[i])
                  .append(" | Recipient: ").append(recipients[i]).append("\n");
            }
        }
        return sb.length() > 0 ? sb.toString().trim() : "No stored messages found.";
    }

    // Option 2b: Display the longest message (checks stored/sent messages)
    public String getLongestMessage() {
        String longest = "";
        for (int i = 0; i < count; i++) {
            if (allMessages[i] != null && allMessages[i].length() > longest.length()) {
                longest = allMessages[i];
            }
        }
        return longest;
    }

    // Option 2c: Search for a message ID and display corresponding recipient and message
    public String searchByMessageID(String searchID) {
        for (int i = 0; i < count; i++) {
            if (messageIDs[i] != null && messageIDs[i].equals(searchID)) {
                return "Recipient: " + recipients[i] + " | Message: " + allMessages[i];
            }
        }
        return "Message ID not found.";
    }

    // Helper returning just the message text for exact unit test assertion
    public String getMessageTextByID(String searchID) {
        for (int i = 0; i < count; i++) {
            if (messageIDs[i] != null && messageIDs[i].equals(searchID)) {
                return allMessages[i];
            }
        }
        return "";
    }

    // Option 2d: Search for all messages sent or stored regarding a particular recipient
    public List<String> searchMessagesByRecipient(String recipientNumber) {
        List<String> results = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            if (recipients[i] != null && recipients[i].equals(recipientNumber)) {
                if ("Sent".equalsIgnoreCase(flags[i]) || "Stored".equalsIgnoreCase(flags[i])) {
                    results.add(allMessages[i]);
                }
            }
        }
        return results;
    }

    // Option 2e: Delete a message using the message hash
    public String deleteMessageByHash(String hash) {
        for (int i = 0; i < count; i++) {
            if (messageHashes[i] != null && messageHashes[i].equalsIgnoreCase(hash)) {
                String deletedMsg = allMessages[i];
                // Shift remaining elements left
                for (int j = i; j < count - 1; j++) {
                    allMessages[j] = allMessages[j + 1];
                    messageIDs[j] = messageIDs[j + 1];
                    messageHashes[j] = messageHashes[j + 1];
                    recipients[j] = recipients[j + 1];
                    developers[j] = developers[j + 1];
                    flags[j] = flags[j + 1];
                }
                count--;
                allMessages[count] = null;
                messageIDs[count] = null;
                messageHashes[count] = null;
                recipients[count] = null;
                developers[count] = null;
                flags[count] = null;
                rebuildCategoryArrays();
                return "Message: \"" + deletedMsg + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    private void rebuildCategoryArrays() {
        sentMessages = new String[allMessages.length];
        disregardedMessages = new String[allMessages.length];
        storedMessages = new String[allMessages.length];
        sentCount = 0;
        disregardedCount = 0;
        storedCount = 0;

        for (int i = 0; i < count; i++) {
            if ("Sent".equalsIgnoreCase(flags[i])) {
                sentMessages[sentCount++] = allMessages[i];
            } else if ("Disregard".equalsIgnoreCase(flags[i]) || "Disregarded".equalsIgnoreCase(flags[i])) {
                disregardedMessages[disregardedCount++] = allMessages[i];
            } else if ("Stored".equalsIgnoreCase(flags[i])) {
                storedMessages[storedCount++] = allMessages[i];
            }
        }
    }

    // Option 2f: Display a report listing full details of all sent/stored messages
    public String displayFullReport() {
        StringBuilder report = new StringBuilder("=== FULL MESSAGE REPORT ===\n");
        for (int i = 0; i < count; i++) {
            report.append("Message Hash: ").append(messageHashes[i]).append("\n")
                  .append("Message ID:   ").append(messageIDs[i]).append("\n")
                  .append("Recipient:    ").append(recipients[i]).append("\n")
                  .append("Developer:    ").append(developers[i]).append("\n")
                  .append("Flag:         ").append(flags[i]).append("\n")
                  .append("Message:      ").append(allMessages[i]).append("\n")
                  .append("-----------------------------------\n");
        }
        return report.toString();
    }

    public String[] getPopulatedSentMessages() {
        String[] result = new String[sentCount];
        System.arraycopy(sentMessages, 0, result, 0, sentCount);
        return result;
    }

    public String[] getPopulatedDisregardedMessages() {
        String[] result = new String[disregardedCount];
        System.arraycopy(disregardedMessages, 0, result, 0, disregardedCount);
        return result;
    }

    public String[] getPopulatedStoredMessages() {
        String[] result = new String[storedCount];
        System.arraycopy(storedMessages, 0, result, 0, storedCount);
        return result;
    }

    public String[] getMessageHashes() { return messageHashes; }
    public String[] getMessageIDs() { return messageIDs; }
}
