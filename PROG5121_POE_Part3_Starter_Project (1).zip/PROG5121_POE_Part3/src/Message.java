public class Message {
    private String messageID;
    private String recipient;
    private String developer;
    private String messageText;
    private String flag;
    private String messageHash;

    public Message(String messageID, String recipient, String developer, String messageText, String flag) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.developer = developer;
        this.messageText = messageText;
        this.flag = flag;
        this.messageHash = createMessageHash();
    }

    // Generates a Message Hash using first two digits of ID, message length, and first/last words
    public String createMessageHash() {
        String idPrefix = (messageID != null && messageID.length() >= 2) ? messageID.substring(0, 2) : "00";
        String cleanText = messageText.trim();
        String[] words = cleanText.split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^a-zA-Z0-9]", "") : "";
        String lastWord = words.length > 1 ? words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "") : firstWord;
        return (idPrefix + ":" + words.length + ":" + firstWord + lastWord).toUpperCase();
    }

    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getDeveloper() { return developer; }
    public String getMessageText() { return messageText; }
    public String getFlag() { return flag; }
    public String getMessageHash() { return messageHash; }
}
