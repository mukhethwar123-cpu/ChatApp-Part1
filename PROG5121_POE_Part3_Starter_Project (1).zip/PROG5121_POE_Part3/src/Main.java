import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MessageManager manager = new MessageManager(50);

        // Populate with the 5 Test Data messages from Part 3
        manager.addMessage(new Message("MSG001", "+27834557896", "Developer 1", "Did you get the cake?", "Sent"));
        manager.addMessage(new Message("MSG002", "+27838884567", "Developer 2", "Where are you? You are late! I have asked you to be on time.", "Stored"));
        manager.addMessage(new Message("MSG003", "+27834484567", "Developer 3", "Yohoooo, I am at your gate.", "Disregard"));
        manager.addMessage(new Message("0838884567", "+27838884567", "0838884567", "It is dinner time!", "Sent"));
        manager.addMessage(new Message("MSG005", "+27838884567", "Developer 5", "Ok, I am leaving without you.", "Stored"));

        // Save and reload JSON for Stored Messages requirement
        manager.saveStoredMessagesToJson("stored_messages.json");
        manager.loadStoredMessagesFromJson("stored_messages.json");

        boolean running = true;
        while (running) {
            System.out.println("\n=== QUICKCHAT MAIN MENU ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show Recently Sent Messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Select an option (1-4): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.print("Enter Message ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Recipient (+27...): ");
                    String rec = scanner.nextLine();
                    System.out.print("Enter Developer/Sender: ");
                    String dev = scanner.nextLine();
                    System.out.print("Enter Message: ");
                    String text = scanner.nextLine();
                    System.out.print("Enter Flag (Sent / Stored / Disregard): ");
                    String flag = scanner.nextLine();
                    manager.addMessage(new Message(id, rec, dev, text, flag));
                    manager.saveStoredMessagesToJson("stored_messages.json");
                    System.out.println("Message recorded.");
                    break;

                case "2":
                    System.out.println("\n--- Recently Sent Messages ---");
                    for (String sent : manager.getPopulatedSentMessages()) {
                        System.out.println("- " + sent);
                    }
                    break;

                case "3":
                    running = false;
                    System.out.println("Exiting application...");
                    break;

                case "4":
                    handleStoredMessagesMenu(scanner, manager);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter 1-4.");
            }
        }
        scanner.close();
    }

    private static void handleStoredMessagesMenu(Scanner scanner, MessageManager manager) {
        System.out.println("\n--- STORED MESSAGES MENU ---");
        System.out.println("a. Display the sender and recipient of all stored messages");
        System.out.println("b. Display the longest stored message");
        System.out.println("c. Search for a message ID and display recipient and message");
        System.out.println("d. Search for all messages stored for a particular recipient");
        System.out.println("e. Delete a message using the message hash");
        System.out.println("f. Display a report listing full details of all messages");
        System.out.print("Choose an option (a-f): ");

        String subChoice = scanner.nextLine().trim().toLowerCase();

        switch (subChoice) {
            case "a":
                System.out.println(manager.displaySenderAndRecipientOfStored());
                break;
            case "b":
                System.out.println("Longest Message: " + manager.getLongestMessage());
                break;
            case "c":
                System.out.print("Enter Message ID to search: ");
                String searchId = scanner.nextLine().trim();
                System.out.println(manager.searchByMessageID(searchId));
                break;
            case "d":
                System.out.print("Enter Recipient number to search: ");
                String searchRec = scanner.nextLine().trim();
                List<String> found = manager.searchMessagesByRecipient(searchRec);
                if (found.isEmpty()) {
                    System.out.println("No messages found for recipient.");
                } else {
                    for (String m : found) {
                        System.out.println("- " + m);
                    }
                }
                break;
            case "e":
                System.out.print("Enter Message Hash to delete: ");
                String hash = scanner.nextLine().trim();
                System.out.println(manager.deleteMessageByHash(hash));
                break;
            case "f":
                System.out.println(manager.displayFullReport());
                break;
            default:
                System.out.println("Invalid sub-option.");
        }
    }
}
