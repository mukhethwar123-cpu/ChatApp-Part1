package st10486740_chatapp_poe;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ST10486740_ChatApp_POEJUnitTest {

    @BeforeEach
    public void setUp() {
        // Resets all arrays and loads the 5 test messages
        Message.populateWithTestData();
    }

    // ---------- Message basics ----------

    @Test
    public void testMessageIDIsTenDigits() {
        Message m = new Message();
        assertTrue(m.checkMessageID());
        assertTrue(m.getMessageID().matches("\\d{10}"));
    }

    @Test
    public void testCheckRecipientCellSuccess() {
        assertEquals(1, new Message().checkRecipientCell("+27718693002"));
    }

    @Test
    public void testCheckRecipientCellFailureNoInternationalCode() {
        assertEquals(0, new Message().checkRecipientCell("08575975889"));
    }

    @Test
    public void testCheckRecipientCellFailureNonDigits() {
        assertEquals(0, new Message().checkRecipientCell("+2771abc3002"));
    }

    @Test
    public void testCheckRecipientCellFailureTooLong() {
        assertEquals(0, new Message().checkRecipientCell("+271234567890123"));
    }

    @Test
    public void testMessageHashFormat() {
        Message m = new Message();
        m.setRecipient("+27718693002");
        m.setMessage("Hi Mike, can you join us for dinner tonight");
        String expected = m.getMessageID().substring(0, 2) + ":" + m.getMessageCount() + ":HITONIGHT";
        assertEquals(expected, m.getMessageHash());
        assertEquals(m.getMessageHash().toUpperCase(), m.getMessageHash());
    }

    @Test
    public void testMessageHashSingleWord() {
        Message m = new Message();
        m.setMessage("Hello");
        assertTrue(m.getMessageHash().endsWith(":HELLOHELLO"));
    }

    @Test
    public void testSentMessageDiscard() {
        Message m = new Message();
        m.setRecipient("+27718693002");
        m.setMessage("Discard me");
        int before = Message.getDisregardedMessages().size();
        assertEquals("Message disregarded.", m.sentMessage(2));
        assertEquals("discarded", m.getStatus());
        assertEquals(before + 1, Message.getDisregardedMessages().size());
    }

    @Test
    public void testSentMessageInvalidOption() {
        assertEquals("Invalid option.", new Message().sentMessage(9));
    }

    @Test
    public void testSentMessageSendIncrementsTotal() {
        Message m = new Message();
        m.setRecipient("+27718693002");
        m.setMessage("Send me");
        int before = Message.returnTotalMessages();
        assertEquals("Message successfully sent.", m.sentMessage(1));
        assertEquals(before + 1, Message.returnTotalMessages());
        assertEquals("sent", m.getStatus());
    }

    @Test
    public void testSentMessageStore() {
        Message m = new Message();
        m.setRecipient("+27718693002");
        m.setMessage("Store me");
        int before = Message.getStoredMessages().size();
        assertEquals("Message successfully stored.", m.sentMessage(3));
        assertEquals("stored", m.getStatus());
        assertEquals(before + 1, Message.getStoredMessages().size());
    }

    @Test
    public void testPrintMessagesContainsDetails() {
        Message m = new Message();
        m.setRecipient("+27718693002");
        m.setMessage("Print me");
        String out = m.printMessages();
        assertTrue(out.contains(m.getMessageID()));
        assertTrue(out.contains("+27718693002"));
        assertTrue(out.contains("Print me"));
    }

    // ---------- Test data / arrays ----------

    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals(2, Message.getSentMessages().size());
        assertEquals("Did you get the cake?", Message.getSentMessages().get(0).getMessage());
        assertEquals("It is dinner time!", Message.getSentMessages().get(1).getMessage());
    }

    @Test
    public void testStoredMessagesArrayPopulated() {
        assertEquals(2, Message.getStoredMessages().size());
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                Message.getStoredMessages().get(0).getMessage());
        assertEquals("Ok, I am leaving without you.", Message.getStoredMessages().get(1).getMessage());
    }

    @Test
    public void testDisregardedMessagesArrayPopulated() {
        assertEquals(1, Message.getDisregardedMessages().size());
        assertEquals("Yohoooo, I am at your gate.", Message.getDisregardedMessages().get(0).getMessage());
    }

    // ---------- Array operations ----------

    @Test
    public void testDisplaySentMessagesSendersRecipients() {
        String out = Message.displaySentMessagesSendersRecipients();
        assertTrue(out.contains("+2783457896"));
        assertTrue(out.contains("Did you get the cake?"));
        assertTrue(out.contains("0838884567"));
        assertTrue(out.contains("It is dinner time!"));
    }

    @Test
    public void testDisplaySentMessagesWhenEmpty() {
        Message.getSentMessages().clear();
        assertEquals("No sent messages found.", Message.displaySentMessagesSendersRecipients());
    }

    @Test
    public void testDisplayLongestSentMessage() {
        String out = Message.displayLongestSentMessage();
        assertTrue(out.contains("Did you get the cake?"));
        assertTrue(out.contains("Length: 21 characters"));
    }

    @Test
    public void testDisplayLongestSentMessageWhenEmpty() {
        Message.getSentMessages().clear();
        assertEquals("No sent messages found.", Message.displayLongestSentMessage());
    }

    @Test
    public void testSearchMessageByIDFoundInSent() {
        Message m = Message.getSentMessages().get(0);
        String out = Message.searchMessageByID(m.getMessageID());
        assertTrue(out.startsWith("Message Found:"));
        assertTrue(out.contains("Did you get the cake?"));
    }

    @Test
    public void testSearchMessageByIDFoundInStored() {
        Message m = Message.getStoredMessages().get(1);
        String out = Message.searchMessageByID(m.getMessageID());
        assertTrue(out.startsWith("Message Found (Stored):"));
        assertTrue(out.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testSearchMessageByIDNotFound() {
        assertEquals("No message found with ID: 0000000000", Message.searchMessageByID("0000000000"));
    }

    @Test
    public void testSearchMessagesByRecipientFound() {
        String out = Message.searchMessagesByRecipient("+27838884567");
        assertTrue(out.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(out.contains("Status: stored"));
    }

    @Test
    public void testSearchMessagesByRecipientNotFound() {
        assertEquals("No messages found for recipient: +27000000000",
                Message.searchMessagesByRecipient("+27000000000"));
    }

    @Test
    public void testDeleteMessageByHashFromSent() {
        Message m = Message.getSentMessages().get(0);
        String out = Message.deleteMessageByHash(m.getMessageHash());
        assertEquals("Message successfully deleted: Did you get the cake?", out);
        assertEquals(1, Message.getSentMessages().size());
    }

    @Test
    public void testDeleteMessageByHashFromStored() {
        Message m = Message.getStoredMessages().get(0);
        String out = Message.deleteMessageByHash(m.getMessageHash());
        assertTrue(out.startsWith("Message successfully deleted"));
        assertEquals(1, Message.getStoredMessages().size());
    }

    @Test
    public void testDeleteMessageByHashNotFound() {
        assertEquals("No message found with hash: NOPE", Message.deleteMessageByHash("NOPE"));
    }

    @Test
    public void testDisplayFullReport() {
        String out = Message.displayFullReport();
        assertTrue(out.contains("FULL MESSAGE REPORT"));
        assertTrue(out.contains("Did you get the cake?"));
        assertTrue(out.contains("It is dinner time!"));
        assertTrue(out.contains("Total Sent Messages: 2"));
    }

    @Test
    public void testDisplayFullReportWhenEmpty() {
        Message.getSentMessages().clear();
        assertEquals("No sent messages to display in report.", Message.displayFullReport());
    }
}
